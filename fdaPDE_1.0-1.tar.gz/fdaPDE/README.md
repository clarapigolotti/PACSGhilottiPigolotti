# PACSGhilottiPigolotti
version without OMP
